function popupWindow(mypage, myname, w, h, scroll) {
	var winl = (screen.width - w) / 2;
	var wint = (screen.height - h) / 2;
	winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
	win = window.open(mypage, myname, winprops)
	if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}

function getSelectedText( frmName, srcListName ) {
	var form = eval( 'document.' + frmName );
	var srcList = eval( 'form.' + srcListName );

	i = srcList.selectedIndex;
	if (i != null && i > -1) {
		return srcList.options[i].text;
	} else {
		return null;
	}
}

function fGetElementById(id) {
if (document.getElementById(id)) {
	return document.getElementById(id);
	} else if (document.all[id]) {
		return document.all[id];
		} else if (document.layers && document.layers[id]) {
			return (document.layers[id]);
			} else {
				return false;
			}
}

function toggleDisplay(id) {
	var elestyle = fGetElementById(id).style;
	if (elestyle.display == "block" || elestyle.display == "") {
		elestyle.display = 'none';
	} else {
		elestyle.display = "block";
	}
}

function toggleOn(id) {
	var elestyle = fGetElementById(id).style;	
	elestyle.display = "block";	
}